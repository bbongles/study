package com.fastcampus.jpa.bookmanager.domain;

/**
 * @author Martin
 * @since 2021/03/31
 */
public enum Gender {
    MALE,
    FEMALE
}
